//
//  AppProfesionalesApp.swift
//  AppProfesionales
//
//  Created by Francisco Martín on 02/03/2026.
//

import SwiftUI

@main
struct AppProfesionalesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
