//
//  ContentView.swift
//  AppProfesionales
//
//  App principal para profesionales que ofrecen servicios (equivalente "app conductores").
//

import SwiftUI

enum MainProTab: String, CaseIterable, Hashable {
    case inicio
    case trabajos
    case agenda
    case ingresos
    case perfil
}

struct ContentView: View {
    @State private var selectedTab: MainProTab = .inicio

    var body: some View {
        TabView(selection: $selectedTab) {
            HomeProView()
                .tabItem { Label("Inicio", systemImage: "house.fill") }
                .tag(MainProTab.inicio)

            JobsProView()
                .tabItem { Label("Trabajos", systemImage: "briefcase.fill") }
                .tag(MainProTab.trabajos)

            AgendaProView()
                .tabItem { Label("Agenda", systemImage: "calendar") }
                .tag(MainProTab.agenda)

            EarningsProView()
                .tabItem { Label("Ingresos", systemImage: "banknote.fill") }
                .tag(MainProTab.ingresos)

            ProfileProView()
                .tabItem { Label("Perfil", systemImage: "person.crop.circle.fill") }
                .tag(MainProTab.perfil)
        }
        .tint(.indigo)
    }
}

// MARK: - Inicio / Dashboard
private struct HomeProView: View {
    @State private var isAvailable = true
    @State private var showNotifications = false
    private let newRequests = ProMockSeed.newRequests
    private let acceptedJobs = ProMockSeed.acceptedJobs
    private let inProgressJobs = ProMockSeed.inProgressJobs
    private let notifications = ProMockSeed.notifications

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    headerSection
                    availabilityToggle
                    topPanel
                    if !newRequests.isEmpty {
                        newRequestsSection
                    }
                    upcomingJobsSection
                    notificationsPreview
                }
                .padding(16)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Inicio")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showNotifications = true
                    } label: {
                        ZStack(alignment: .topTrailing) {
                            Image(systemName: "bell.fill")
                                .font(.title3)
                            if notifications.contains(where: { !$0.isRead }) {
                                Circle()
                                    .fill(.red)
                                    .frame(width: 9, height: 9)
                                    .overlay(Circle().stroke(Color(uiColor: .systemBackground), lineWidth: 1.2))
                                    .offset(x: 4, y: -4)
                            }
                        }
                        .foregroundStyle(.indigo)
                    }
                }
            }
            .sheet(isPresented: $showNotifications) {
                ProNotificationsPanelView(notifications: notifications)
            }
        }
    }

    private var headerSection: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Hola, \(ProMockSeed.professionalName.components(separatedBy: " ").first ?? "Profesional") 👋")
                .font(.system(size: 26, weight: .bold))
            Text("Gestioná tus trabajos e ingresos desde acá.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
    }

    private var availabilityToggle: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("Disponible para recibir trabajos")
                    .font(.subheadline.weight(.semibold))
                Text(isAvailable ? "Los clientes pueden enviarte solicitudes" : "No recibirás nuevas solicitudes")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Toggle("", isOn: $isAvailable)
                .labelsHidden()
                .tint(.indigo)
        }
        .padding(14)
        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 14))
    }

    private var topPanel: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Resumen del día")
                .font(.headline)
            HStack(spacing: 10) {
                ProStatBadge(title: "Solicitudes", value: "\(newRequests.count)", color: .orange)
                ProStatBadge(title: "Ingresos hoy", value: ProMockSeed.earningsToday, color: .green)
                ProStatBadge(title: "En curso", value: "\(inProgressJobs.count)", color: .indigo)
            }
        }
        .padding(14)
        .background(
            LinearGradient(colors: [.indigo.opacity(0.2), .cyan.opacity(0.12)], startPoint: .topLeading, endPoint: .bottomTrailing),
            in: RoundedRectangle(cornerRadius: 16)
        )
    }

    private var newRequestsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Nuevas solicitudes")
                    .font(.headline)
                Spacer()
                Text("\(newRequests.count)")
                    .font(.headline)
                    .foregroundStyle(.white)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(.orange, in: Capsule())
            }
            ForEach(newRequests.prefix(2)) { job in
                NavigationLink {
                    JobRequestDetailView(job: job)
                } label: {
                    ProJobRequestCard(job: job)
                }
                .buttonStyle(.plain)
            }
        }
    }

    private var upcomingJobsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Próximos trabajos")
                .font(.headline)
            let all = (acceptedJobs + inProgressJobs).prefix(3)
            ForEach(Array(all), id: \.id) { job in
                NavigationLink {
                    JobRequestDetailView(job: job)
                } label: {
                    ProJobRequestRow(job: job)
                }
                .buttonStyle(.plain)
            }
        }
    }

    private var notificationsPreview: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Notificaciones")
                    .font(.headline)
                Spacer()
                Button("Ver todas") { showNotifications = true }
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.indigo)
            }
            ForEach(notifications.prefix(2)) { notice in
                ProNotificationRow(notice: notice)
            }
        }
    }
}

// MARK: - Trabajos
private struct JobsProView: View {
    @State private var selectedFilter: JobFilter = .nuevas
    private let newRequests = ProMockSeed.newRequests
    private let acceptedJobs = ProMockSeed.acceptedJobs
    private let inProgressJobs = ProMockSeed.inProgressJobs
    private let completedJobs = ProMockSeed.completedJobs

    enum JobFilter: String, CaseIterable {
        case nuevas = "Nuevas"
        case aceptadas = "Aceptadas"
        case enCurso = "En curso"
        case completadas = "Completadas"
    }

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 0) {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(JobFilter.allCases, id: \.self) { filter in
                            let isSelected = selectedFilter == filter
                            Button {
                                selectedFilter = filter
                            } label: {
                                Text(filter.rawValue)
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(isSelected ? .white : .primary)
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 8)
                                    .background(isSelected ? Color.indigo : Color(uiColor: .secondarySystemBackground), in: Capsule())
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                }
                List {
                    Section {
                        ForEach(jobsForFilter) { job in
                            NavigationLink {
                                JobRequestDetailView(job: job)
                            } label: {
                                ProJobRequestRow(job: job)
                            }
                        }
                    }
                }
                .listStyle(.insetGrouped)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Trabajos")
        }
    }

    private var jobsForFilter: [ProJobRequest] {
        switch selectedFilter {
        case .nuevas: return newRequests
        case .aceptadas: return acceptedJobs
        case .enCurso: return inProgressJobs
        case .completadas: return completedJobs
        }
    }
}

// MARK: - Agenda
private struct AgendaProView: View {
    @State private var selectedDate = Date()
    private let todayAgenda = ProMockSeed.todayAgenda

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("Hoy, \(formattedDate(selectedDate))")
                        .font(.headline)
                    VStack(spacing: 0) {
                        ForEach(todayAgenda) { item in
                            ProAgendaRow(item: item)
                            if item.id != todayAgenda.last?.id {
                                Divider()
                                    .padding(.leading, 56)
                            }
                        }
                    }
                    .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 14))

                    GroupBox("Tu disponibilidad semanal") {
                        VStack(alignment: .leading, spacing: 8) {
                            ForEach(ProMockSeed.availabilitySlots) { slot in
                                HStack {
                                    Text(slot.dayOfWeek)
                                        .font(.subheadline.weight(.medium))
                                    Spacer()
                                    if slot.isActive {
                                        Text("\(slot.startTime) - \(slot.endTime)")
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    } else {
                                        Text("No disponible")
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    }
                                }
                                .padding(.vertical, 4)
                            }
                        }
                    }
                }
                .padding(16)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Agenda")
        }
    }

    private func formattedDate(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "EEEE d MMM"
        f.locale = Locale(identifier: "es_AR")
        return f.string(from: date)
    }
}

// MARK: - Ingresos
private struct EarningsProView: View {
    private let recentEarnings = ProMockSeed.recentEarnings
    private let withdrawals = ProMockSeed.withdrawals

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    summaryCards
                    GroupBox("Últimos ingresos") {
                        VStack(spacing: 0) {
                            ForEach(recentEarnings) { earning in
                                ProEarningRow(earning: earning)
                                if earning.id != recentEarnings.last?.id {
                                    Divider().padding(.leading, 48)
                                }
                            }
                        }
                    }
                    GroupBox("Retiros") {
                        VStack(spacing: 10) {
                            ForEach(withdrawals) { w in
                                ProWithdrawalRow(withdrawal: w)
                            }
                        }
                    }
                    HStack(spacing: 10) {
                        Button("Solicitar retiro") {}
                            .buttonStyle(.borderedProminent)
                        Button("Ver historial completo") {}
                            .buttonStyle(.bordered)
                    }
                }
                .padding(16)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Ingresos")
        }
    }

    private var summaryCards: some View {
        VStack(spacing: 12) {
            HStack(spacing: 12) {
                ProEarningSummaryCard(title: "Hoy", amount: ProMockSeed.earningsToday, color: .green)
                ProEarningSummaryCard(title: "Esta semana", amount: ProMockSeed.earningsWeek, color: .indigo)
            }
            ProEarningSummaryCard(title: "Este mes", amount: ProMockSeed.earningsMonth, color: .orange)
        }
    }
}

// MARK: - Perfil
private struct ProfileProView: View {
    private let menu = ProMockSeed.profileMenuItems

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    profileHeader
                    ForEach(menu) { item in
                        NavigationLink {
                            ProProfileSubmenuDetailView(item: item)
                        } label: {
                            ProProfileRow(title: item.title, icon: item.icon, color: item.color)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(16)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Perfil")
        }
    }

    private var profileHeader: some View {
        VStack(spacing: 10) {
            ProAvatarView(urlString: ProMockSeed.professionalAvatarURL, size: 88)
            Text(ProMockSeed.professionalName)
                .font(.title3.weight(.bold))
            Text(ProMockSeed.professionalTitle)
                .font(.subheadline)
                .foregroundStyle(.secondary)
            HStack(spacing: 16) {
                Label("\(String(format: "%.1f", ProMockSeed.professionalRating))", systemImage: "star.fill")
                    .foregroundStyle(.orange)
                Text("\(ProMockSeed.professionalReviews) reseñas")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text("• \(ProMockSeed.professionalResponseTime) respuesta")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Text("Cuenta profesional verificada")
                .font(.caption.weight(.medium))
                .foregroundStyle(.indigo)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 18)
        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 16))
    }
}

// MARK: - Detalle solicitud
private struct JobRequestDetailView: View {
    let job: ProJobRequest

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                clientSection
                serviceSection
                locationSection
                priceAndStatusSection
                if let notes = job.notes, !notes.isEmpty {
                    GroupBox("Notas del cliente") {
                        Text(notes)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }
                actionsSection
            }
            .padding(16)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Detalle del trabajo")
        .navigationBarTitleDisplayMode(.inline)
    }

    private var clientSection: some View {
        GroupBox("Cliente") {
            HStack(spacing: 12) {
                ProAvatarView(urlString: job.clientAvatarURL, size: 52)
                VStack(alignment: .leading, spacing: 4) {
                    Text(job.clientName)
                        .font(.headline)
                    Label(job.clientPhone, systemImage: "phone.fill")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }
        }
    }

    private var serviceSection: some View {
        GroupBox("Servicio") {
            VStack(alignment: .leading, spacing: 6) {
                Text(job.serviceTitle)
                    .font(.headline)
                Text(job.serviceCategory)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Label("\(job.date) • \(job.time)", systemImage: "calendar.badge.clock")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var locationSection: some View {
        GroupBox("Dirección") {
            Label(job.address, systemImage: "mappin.and.ellipse")
                .font(.subheadline)
        }
    }

    private var priceAndStatusSection: some View {
        GroupBox("Pago y estado") {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Monto")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text(job.price)
                        .font(.title3.weight(.bold))
                }
                Spacer()
                Text(job.status.rawValue)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(job.status.color, in: Capsule())
            }
        }
    }

    private var actionsSection: some View {
        VStack(spacing: 10) {
            switch job.status {
            case .nueva:
                Button("Aceptar solicitud") {}
                    .buttonStyle(.borderedProminent)
                    .frame(maxWidth: .infinity)
                Button("Rechazar") {}
                    .buttonStyle(.bordered)
                    .frame(maxWidth: .infinity)
            case .aceptada:
                Button("Estoy en camino") {}
                    .buttonStyle(.borderedProminent)
                    .frame(maxWidth: .infinity)
                Button("Llamar al cliente") {}
                    .buttonStyle(.bordered)
                    .frame(maxWidth: .infinity)
            case .enCamino, .enCurso:
                Button("Iniciar trabajo") {}
                    .buttonStyle(.borderedProminent)
                    .frame(maxWidth: .infinity)
                Button("Marcar como completado") {}
                    .buttonStyle(.bordered)
                    .frame(maxWidth: .infinity)
                Button("Llamar al cliente") {}
                    .buttonStyle(.bordered)
                    .frame(maxWidth: .infinity)
            default:
                EmptyView()
            }
        }
    }
}

// MARK: - Panel notificaciones
private struct ProNotificationsPanelView: View {
    let notifications: [ProNotification]

    var body: some View {
        NavigationStack {
            List {
                Section("No leídas") {
                    ForEach(notifications.filter { !$0.isRead }) { notice in
                        NavigationLink {
                            ProNotificationDetailView(notice: notice)
                        } label: {
                            ProNotificationRow(notice: notice)
                        }
                    }
                }
                Section("Anteriores") {
                    ForEach(notifications.filter { $0.isRead }) { notice in
                        NavigationLink {
                            ProNotificationDetailView(notice: notice)
                        } label: {
                            ProNotificationRow(notice: notice)
                        }
                    }
                }
            }
            .navigationTitle("Notificaciones")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Marcar todo leído") {}
                        .font(.caption.weight(.semibold))
                }
            }
        }
    }
}

// MARK: - Detalle notificación
private struct ProNotificationDetailView: View {
    let notice: ProNotification

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 10) {
                    Image(systemName: notice.icon)
                        .font(.title2)
                        .foregroundStyle(notice.color)
                    Text(notice.title)
                        .font(.title3.weight(.bold))
                }
                Text(notice.message)
                    .font(.body)
                Text("Recibida: \(notice.time)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                GroupBox("Acciones") {
                    HStack(spacing: 8) {
                        Button("Ir al detalle") {}
                            .buttonStyle(.borderedProminent)
                        Button("Descartar") {}
                            .buttonStyle(.bordered)
                    }
                }
            }
            .padding(16)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Detalle notificación")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Submenús perfil
private struct ProProfileSubmenuDetailView: View {
    let item: ProProfileMenuItem

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 10) {
                    Image(systemName: item.icon)
                        .foregroundStyle(item.color)
                        .font(.title2)
                    Text(item.title)
                        .font(.title3.weight(.bold))
                }
                contentForSection
            }
            .padding(16)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle(item.title)
        .navigationBarTitleDisplayMode(.inline)
    }

    @ViewBuilder
    private var contentForSection: some View {
        switch item.section {
        case .datos:
            proPersonalDataSection
        case .misServicios:
            proMyServicesSection
        case .zonas:
            proZonesSection
        case .disponibilidad:
            proAvailabilitySection
        case .datosBancarios:
            proBankingSection
        case .estadisticas:
            proStatsSection
        case .soporte:
            proSupportSection
        case .privacidad:
            proPrivacySection
        }
    }

    private var proPersonalDataSection: some View {
        VStack(spacing: 12) {
            GroupBox("Información personal") {
                VStack(alignment: .leading, spacing: 10) {
                    ProInfoRow(label: "Nombre", value: ProMockSeed.professionalName)
                    ProInfoRow(label: "Correo", value: "carlos.mendez@email.com")
                    ProInfoRow(label: "Teléfono", value: "+54 11 4567 8901")
                    ProInfoRow(label: "Documento", value: "DNI verificado")
                    ProInfoRow(label: "Miembro desde", value: "Marzo 2022")
                }
            }
            Button("Editar datos") {}
                .buttonStyle(.borderedProminent)
        }
    }

    private var proMyServicesSection: some View {
        VStack(spacing: 12) {
            GroupBox("Servicios que ofrezco") {
                VStack(spacing: 10) {
                    ForEach(ProMockSeed.myServices) { service in
                        HStack(spacing: 12) {
                            AsyncImage(url: URL(string: service.imageURL)) { phase in
                                if let image = phase.image {
                                    image.resizable().scaledToFill()
                                } else {
                                    Color.gray.opacity(0.2)
                                }
                            }
                            .frame(width: 56, height: 56)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                            VStack(alignment: .leading, spacing: 4) {
                                Text(service.title)
                                    .font(.subheadline.weight(.bold))
                                Text(service.startingPrice)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: service.isActive ? "checkmark.circle.fill" : "pause.circle.fill")
                                .foregroundStyle(service.isActive ? .green : .orange)
                        }
                        .padding(8)
                        .background(Color(uiColor: .tertiarySystemBackground), in: RoundedRectangle(cornerRadius: 10))
                    }
                }
            }
            Button("Agregar o editar servicios") {}
                .buttonStyle(.borderedProminent)
        }
    }

    private var proZonesSection: some View {
        VStack(spacing: 12) {
            GroupBox("Zonas de cobertura") {
                VStack(alignment: .leading, spacing: 8) {
                    ProChipsView(items: ProMockSeed.professionalZones)
                    Text("Los clientes de estas zonas pueden encontrarte.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            Button("Editar zonas") {}
                .buttonStyle(.borderedProminent)
        }
    }

    private var proAvailabilitySection: some View {
        VStack(spacing: 12) {
            GroupBox("Horarios de disponibilidad") {
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(ProMockSeed.availabilitySlots) { slot in
                        HStack {
                            Text(slot.dayOfWeek)
                            Spacer()
                            if slot.isActive {
                                Text("\(slot.startTime) - \(slot.endTime)")
                                    .foregroundStyle(.secondary)
                            } else {
                                Text("No disponible")
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .font(.subheadline)
                        .padding(.vertical, 4)
                    }
                }
            }
            Button("Editar disponibilidad") {}
                .buttonStyle(.borderedProminent)
        }
    }

    private var proBankingSection: some View {
        VStack(spacing: 12) {
            GroupBox("Datos bancarios") {
                VStack(alignment: .leading, spacing: 10) {
                    ProInfoRow(label: "CBU/CVU", value: "•••• •••• •••• 4521")
                    ProInfoRow(label: "Alias", value: "carlos.electricista.cbu")
                    ProInfoRow(label: "Titular", value: ProMockSeed.professionalName)
                }
            }
            GroupBox("Retiros") {
                VStack(alignment: .leading, spacing: 8) {
                    Label("Próximo retiro disponible: \(ProMockSeed.earningsWeek)", systemImage: "banknote")
                    Label("Frecuencia: Semanal (lunes)", systemImage: "calendar")
                }
                .font(.subheadline)
                .foregroundStyle(.secondary)
            }
            Button("Modificar datos bancarios") {}
                .buttonStyle(.borderedProminent)
        }
    }

    private var proStatsSection: some View {
        VStack(spacing: 12) {
            GroupBox("Estadísticas") {
                HStack(spacing: 10) {
                    ProStatBadge(title: "Trabajos", value: "\(ProMockSeed.professionalCompletedJobs)", color: .indigo)
                    ProStatBadge(title: "Valoración", value: String(format: "%.1f", ProMockSeed.professionalRating), color: .orange)
                    ProStatBadge(title: "Responde en", value: ProMockSeed.professionalResponseTime, color: .mint)
                }
            }
            GroupBox("Últimas reseñas") {
                VStack(alignment: .leading, spacing: 10) {
                    Text("\"Muy profesional y puntual. Recomendado.\"")
                        .font(.subheadline)
                        .italic()
                    Text("— Lucas Pérez • 5 estrellas")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            Button("Ver todas las reseñas") {}
                .buttonStyle(.bordered)
        }
    }

    private var proSupportSection: some View {
        GroupBox("Canales de ayuda") {
            VStack(spacing: 10) {
                ProSupportRow(icon: "message.fill", title: "Chat en vivo", subtitle: "Respuesta estimada: 2-5 min")
                ProSupportRow(icon: "phone.fill", title: "Soporte telefónico", subtitle: "Lunes a sábado • 08:00-22:00")
                ProSupportRow(icon: "envelope.fill", title: "Soporte por correo", subtitle: "soporte@appservicios.com")
            }
        }
    }

    private var proPrivacySection: some View {
        VStack(spacing: 12) {
            GroupBox("Seguridad") {
                VStack(alignment: .leading, spacing: 10) {
                    ProInfoRow(label: "Autenticación en dos pasos", value: "Activada")
                    ProInfoRow(label: "Sesiones activas", value: "1 dispositivo")
                }
            }
            Button("Cerrar sesión") {}
                .buttonStyle(.bordered)
                .foregroundStyle(.red)
        }
    }
}

// MARK: - Componentes reutilizables
private struct ProStatBadge: View {
    let title: String
    let value: String
    let color: Color

    var body: some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.headline.weight(.bold))
            Text(title)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 10))
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(color.opacity(0.3), lineWidth: 1))
    }
}

private struct ProAvatarView: View {
    let urlString: String?
    let size: CGFloat

    var body: some View {
        Group {
            if let urlString = urlString, let url = URL(string: urlString) {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image.resizable().scaledToFill()
                    default:
                        placeholder
                    }
                }
            } else {
                placeholder
            }
        }
        .frame(width: size, height: size)
        .clipShape(Circle())
        .overlay(Circle().stroke(Color(uiColor: .systemBackground), lineWidth: 2))
    }

    private var placeholder: some View {
        ZStack {
            LinearGradient(colors: [.indigo.opacity(0.5), .cyan.opacity(0.35)], startPoint: .topLeading, endPoint: .bottomTrailing)
            Image(systemName: "person.fill")
                .foregroundStyle(.white)
                .font(.system(size: size * 0.4))
        }
    }
}

private struct ProJobRequestCard: View {
    let job: ProJobRequest

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top) {
                ProAvatarView(urlString: job.clientAvatarURL, size: 44)
                VStack(alignment: .leading, spacing: 4) {
                    Text(job.clientName)
                        .font(.headline)
                    Text(job.serviceTitle)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Text(job.requestedAt)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Text(job.status.rawValue)
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(job.status.color, in: Capsule())
            }
            HStack {
                Label(job.date, systemImage: "calendar")
                Label(job.time, systemImage: "clock")
                Spacer()
                Text(job.price)
                    .font(.subheadline.weight(.bold))
            }
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        .padding(14)
        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 14))
    }
}

private struct ProJobRequestRow: View {
    let job: ProJobRequest

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(job.clientName)
                    .font(.headline)
                Spacer()
                Text(job.status.rawValue)
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(job.status.color)
            }
            Text(job.serviceTitle)
                .font(.subheadline)
                .foregroundStyle(.secondary)
            HStack {
                Label("\(job.date) • \(job.time)", systemImage: "calendar")
                Spacer()
                Text(job.price)
                    .font(.subheadline.weight(.bold))
            }
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        .padding(.vertical, 6)
    }
}

private struct ProAgendaRow: View {
    let item: ProAgendaItem

    var body: some View {
        HStack(spacing: 14) {
            VStack(spacing: 2) {
                Text(item.time)
                    .font(.subheadline.weight(.bold))
                RoundedRectangle(cornerRadius: 2)
                    .fill(item.status.color)
                    .frame(width: 4)
                    .frame(maxHeight: .infinity)
            }
            .frame(width: 44, alignment: .leading)
            VStack(alignment: .leading, spacing: 4) {
                Text(item.clientName)
                    .font(.subheadline.weight(.semibold))
                Text(item.serviceTitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(item.address)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Text(item.status.rawValue)
                .font(.caption2.weight(.semibold))
                .foregroundStyle(item.status.color)
        }
        .padding(12)
    }
}

private struct ProNotificationRow: View {
    let notice: ProNotification

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: notice.icon)
                .foregroundStyle(notice.color)
                .font(.title3)
                .frame(width: 24)
            VStack(alignment: .leading, spacing: 4) {
                Text(notice.title)
                    .font(.subheadline.weight(.semibold))
                Text(notice.message)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(notice.time)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            if !notice.isRead {
                Circle()
                    .fill(.indigo)
                    .frame(width: 8, height: 8)
            }
        }
        .padding(10)
        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
    }
}

private struct ProEarningSummaryCard: View {
    let title: String
    let amount: String
    let color: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Text(amount)
                .font(.title2.weight(.bold))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(color.opacity(0.15), in: RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(color.opacity(0.3), lineWidth: 1))
    }
}

private struct ProEarningRow: View {
    let earning: ProEarning

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "banknote.fill")
                .foregroundStyle(.indigo)
                .frame(width: 28)
            VStack(alignment: .leading, spacing: 2) {
                Text(earning.title)
                    .font(.subheadline.weight(.semibold))
                Text(earning.clientName)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 2) {
                Text(earning.amount)
                    .font(.subheadline.weight(.bold))
                Text(earning.status)
                    .font(.caption2)
                    .foregroundStyle(earning.statusColor)
            }
        }
        .padding(10)
    }
}

private struct ProWithdrawalRow: View {
    let withdrawal: ProWithdrawal

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(withdrawal.amount)
                    .font(.headline)
                Text(withdrawal.date)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(withdrawal.method)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Text(withdrawal.status)
                .font(.caption.weight(.semibold))
                .foregroundStyle(withdrawal.statusColor)
        }
        .padding(10)
        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 10))
    }
}

private struct ProProfileRow: View {
    let title: String
    let icon: String
    let color: Color

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(color)
                .frame(width: 24)
            Text(title)
            Spacer()
            Image(systemName: "chevron.right")
                .font(.caption.weight(.bold))
                .foregroundStyle(.secondary)
        }
        .padding(14)
        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
    }
}

private struct ProInfoRow: View {
    let label: String
    let value: String

    var body: some View {
        HStack(alignment: .top) {
            Text(label)
                .foregroundStyle(.secondary)
            Spacer()
            Text(value)
                .multilineTextAlignment(.trailing)
                .fontWeight(.semibold)
        }
        .font(.subheadline)
    }
}

private struct ProChipsView: View {
    let items: [String]

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(items, id: \.self) { item in
                    Text(item)
                        .font(.caption.weight(.semibold))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background(Color(uiColor: .tertiarySystemBackground), in: Capsule())
                }
            }
        }
    }
}

private struct ProSupportRow: View {
    let icon: String
    let title: String
    let subtitle: String

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .foregroundStyle(.indigo)
                .frame(width: 24)
            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.subheadline.weight(.bold))
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding(10)
        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 10))
    }
}

#Preview {
    ContentView()
}
