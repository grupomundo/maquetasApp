//
//  Models.swift
//  AppProfesionales
//
//  Modelos de datos para la app de profesionales (solicitudes, ingresos, agenda, etc.)
//

import SwiftUI

// MARK: - Solicitud / Trabajo (vista profesional)
struct ProJobRequest: Identifiable {
    let id: UUID
    init(id: UUID = UUID(), clientName: String, clientAvatarURL: String?, clientPhone: String, serviceTitle: String, serviceCategory: String, address: String, date: String, time: String, price: String, status: ProJobStatus, notes: String?, requestedAt: String) {
        self.id = id
        self.clientName = clientName
        self.clientAvatarURL = clientAvatarURL
        self.clientPhone = clientPhone
        self.serviceTitle = serviceTitle
        self.serviceCategory = serviceCategory
        self.address = address
        self.date = date
        self.time = time
        self.price = price
        self.status = status
        self.notes = notes
        self.requestedAt = requestedAt
    }
    let clientName: String
    let clientAvatarURL: String?
    let clientPhone: String
    let serviceTitle: String
    let serviceCategory: String
    let address: String
    let date: String
    let time: String
    let price: String
    let status: ProJobStatus
    let notes: String?
    let requestedAt: String
}

enum ProJobStatus: String {
    case nueva = "Nueva solicitud"
    case aceptada = "Aceptada"
    case enCamino = "En camino"
    case enCurso = "En curso"
    case completada = "Completada"
    case cancelada = "Cancelada"
    
    var color: Color {
        switch self {
        case .nueva: return .orange
        case .aceptada: return .blue
        case .enCamino: return .indigo
        case .enCurso: return .purple
        case .completada: return .green
        case .cancelada: return .red
        }
    }
    
    var icon: String {
        switch self {
        case .nueva: return "bell.badge.fill"
        case .aceptada: return "checkmark.circle.fill"
        case .enCamino: return "car.fill"
        case .enCurso: return "wrench.and.screwdriver.fill"
        case .completada: return "checkmark.seal.fill"
        case .cancelada: return "xmark.circle.fill"
        }
    }
}

// MARK: - Servicio que ofrece el profesional
struct ProService: Identifiable {
    let id: UUID
    let title: String
    let category: String
    let startingPrice: String
    let duration: String
    let description: String
    let imageURL: String
    let isActive: Bool
}

// MARK: - Notificación (profesional)
struct ProNotification: Identifiable {
    let id: UUID
    let title: String
    let message: String
    let time: String
    let icon: String
    let color: Color
    let isRead: Bool
    let type: ProNotificationType
}

enum ProNotificationType {
    case newRequest
    case reminder
    case payment
    case review
    case system
}

// MARK: - Ingreso / Cobro
struct ProEarning: Identifiable {
    let id: UUID
    let title: String
    let clientName: String
    let amount: String
    let date: String
    let status: String
    let statusColor: Color
}

struct ProWithdrawal: Identifiable {
    let id: UUID
    let amount: String
    let date: String
    let method: String
    let status: String
    let statusColor: Color
}

// MARK: - Bloque de disponibilidad
struct ProAvailabilitySlot: Identifiable {
    let id: UUID
    let dayOfWeek: String
    let startTime: String
    let endTime: String
    let isActive: Bool
}

// MARK: - Turno en agenda
struct ProAgendaItem: Identifiable {
    let id: UUID
    let clientName: String
    let serviceTitle: String
    let address: String
    let time: String
    let status: ProJobStatus
}

// MARK: - Cliente (vista resumida para el profesional)
struct ProClientSummary: Identifiable {
    let id: UUID
    let name: String
    let avatarURL: String?
    let address: String
    let phone: String
    let jobsCompleted: Int
    let lastJobDate: String?
}

// MARK: - Menú perfil profesional
struct ProProfileMenuItem: Identifiable {
    let id: UUID
    let section: ProProfileSection
    let title: String
    let icon: String
    let color: Color
}

enum ProProfileSection {
    case datos
    case misServicios
    case zonas
    case disponibilidad
    case datosBancarios
    case estadisticas
    case soporte
    case privacidad
}
