//
//  ProMockSeed.swift
//  AppProfesionales
//
//  Datos de prueba para la app de profesionales.
//

import SwiftUI

enum ProMockSeed {
    static let professionalName = "Carlos Méndez"
    static let professionalTitle = "Electricista matriculado"
    static let professionalAvatarURL = "https://i.pravatar.cc/300?img=15"
    static let professionalRating = 4.9
    static let professionalReviews = 214
    static let professionalResponseTime = "15 min"
    static let professionalExperience = "8 años"
    static let professionalCompletedJobs = 426
    static let professionalZones = ["Palermo", "Villa Crespo", "Almagro", "Belgrano"]
    
    static let newRequests: [ProJobRequest] = [
        ProJobRequest(
            clientName: "María González",
            clientAvatarURL: "https://i.pravatar.cc/300?img=1",
            clientPhone: "+54 11 1234 5678",
            serviceTitle: "Instalación de tomas y llaves",
            serviceCategory: "Electricidad",
            address: "Honduras 4231, Palermo",
            date: "Hoy",
            time: "18:00",
            price: "$18.000",
            status: .nueva,
            notes: "Timbre B, depto 4.",
            requestedAt: "Hace 12 min"
        ),
        ProJobRequest(
            clientName: "Roberto Fernández",
            clientAvatarURL: "https://i.pravatar.cc/300?img=12",
            clientPhone: "+54 11 8765 4321",
            serviceTitle: "Diagnóstico de tablero eléctrico",
            serviceCategory: "Electricidad",
            address: "Av. Santa Fe 3200, Palermo",
            date: "Mañana",
            time: "10:00",
            price: "$15.500",
            status: .nueva,
            notes: nil,
            requestedAt: "Hace 45 min"
        )
    ]
    
    static let acceptedJobs: [ProJobRequest] = [
        ProJobRequest(
            clientName: "Francisco Martín",
            clientAvatarURL: "https://i.pravatar.cc/300?img=12",
            clientPhone: "+54 11 6789 1234",
            serviceTitle: "Revisión de tablero eléctrico",
            serviceCategory: "Electricidad",
            address: "Honduras 4231, Palermo",
            date: "Hoy",
            time: "16:00",
            price: "$18.000",
            status: .aceptada,
            notes: nil,
            requestedAt: "Ayer"
        )
    ]
    
    static let inProgressJobs: [ProJobRequest] = [
        ProJobRequest(
            clientName: "Ana Martínez",
            clientAvatarURL: "https://i.pravatar.cc/300?img=5",
            clientPhone: "+54 11 5555 1234",
            serviceTitle: "Instalación de lámparas",
            serviceCategory: "Electricidad",
            address: "Gorriti 5200, Palermo",
            date: "Hoy",
            time: "14:00",
            price: "$12.000",
            status: .enCurso,
            notes: "Portería, llamar al llegar.",
            requestedAt: "25 Feb"
        )
    ]

    static let completedJobs: [ProJobRequest] = [
        ProJobRequest(
            clientName: "Lucas Pérez",
            clientAvatarURL: "https://i.pravatar.cc/300?img=33",
            clientPhone: "+54 11 3333 4444",
            serviceTitle: "Instalación de lámparas",
            serviceCategory: "Electricidad",
            address: "Paraguay 3300, Palermo",
            date: "23 Feb",
            time: "11:00",
            price: "$12.300",
            status: .completada,
            notes: nil,
            requestedAt: "22 Feb"
        ),
        ProJobRequest(
            clientName: "Francisco Martín",
            clientAvatarURL: "https://i.pravatar.cc/300?img=12",
            clientPhone: "+54 11 6789 1234",
            serviceTitle: "Revisión de tablero eléctrico",
            serviceCategory: "Electricidad",
            address: "Honduras 4231, Palermo",
            date: "20 Feb",
            time: "16:00",
            price: "$18.000",
            status: .completada,
            notes: nil,
            requestedAt: "19 Feb"
        )
    ]
    
    static let todayAgenda: [ProAgendaItem] = [
        ProAgendaItem(id: UUID(), clientName: "Ana Martínez", serviceTitle: "Instalación de lámparas", address: "Gorriti 5200", time: "14:00", status: .enCurso),
        ProAgendaItem(id: UUID(), clientName: "Francisco Martín", serviceTitle: "Revisión de tablero", address: "Honduras 4231", time: "16:00", status: .aceptada),
        ProAgendaItem(id: UUID(), clientName: "María González", serviceTitle: "Instalación de tomas", address: "Honduras 4231", time: "18:00", status: .nueva)
    ]
    
    static let notifications: [ProNotification] = [
        ProNotification(id: UUID(), title: "Nueva solicitud", message: "María González solicitó Instalación de tomas para hoy 18:00.", time: "Hace 12 min", icon: "bell.badge.fill", color: .orange, isRead: false, type: .newRequest),
        ProNotification(id: UUID(), title: "Pago acreditado", message: "Se acreditó $18.000 por el trabajo con Francisco Martín.", time: "Hace 2 h", icon: "banknote.fill", color: .green, isRead: false, type: .payment),
        ProNotification(id: UUID(), title: "Recordatorio", message: "Próximo trabajo en 2 h: Ana Martínez, Gorriti 5200.", time: "Hace 30 min", icon: "clock.fill", color: .blue, isRead: true, type: .reminder),
        ProNotification(id: UUID(), title: "Nueva reseña", message: "Lucas Pérez te dejó 5 estrellas: \"Muy profesional y puntual\".", time: "Ayer", icon: "star.fill", color: .yellow, isRead: true, type: .review)
    ]
    
    static let earningsToday = "$30.000"
    static let earningsWeek = "$87.500"
    static let earningsMonth = "$312.000"
    
    static let recentEarnings: [ProEarning] = [
        ProEarning(id: UUID(), title: "Revisión de tablero", clientName: "Francisco Martín", amount: "$18.000", date: "Hoy", status: "Acreditado", statusColor: .green),
        ProEarning(id: UUID(), title: "Instalación de lámparas", clientName: "Ana Martínez", amount: "$12.000", date: "Hoy", status: "En proceso", statusColor: .orange),
        ProEarning(id: UUID(), title: "Diagnóstico eléctrico", clientName: "Lucas Pérez", amount: "$15.500", date: "Ayer", status: "Acreditado", statusColor: .green)
    ]
    
    static let withdrawals: [ProWithdrawal] = [
        ProWithdrawal(id: UUID(), amount: "$85.000", date: "28 Feb 2026", method: "CBU •••• 4521", status: "Acreditado", statusColor: .green),
        ProWithdrawal(id: UUID(), amount: "$120.000", date: "21 Feb 2026", method: "CBU •••• 4521", status: "Acreditado", statusColor: .green)
    ]
    
    static let myServices: [ProService] = [
        ProService(id: UUID(), title: "Instalación de tomas y llaves", category: "Electricidad", startingPrice: "Desde $18.000", duration: "60-90 min", description: "Instalación y reemplazo de tomas e interruptores.", imageURL: "https://images.unsplash.com/photo-1621905251918-48416bd8575a?auto=format&fit=crop&w=400&q=80", isActive: true),
        ProService(id: UUID(), title: "Diagnóstico de tablero eléctrico", category: "Electricidad", startingPrice: "Desde $15.500", duration: "45-60 min", description: "Chequeo completo del tablero y detección de fallas.", imageURL: "https://images.unsplash.com/photo-1620283085068-5ee9b49bcf58?auto=format&fit=crop&w=400&q=80", isActive: true)
    ]
    
    static let availabilitySlots: [ProAvailabilitySlot] = [
        ProAvailabilitySlot(id: UUID(), dayOfWeek: "Lunes", startTime: "09:00", endTime: "18:00", isActive: true),
        ProAvailabilitySlot(id: UUID(), dayOfWeek: "Martes", startTime: "09:00", endTime: "18:00", isActive: true),
        ProAvailabilitySlot(id: UUID(), dayOfWeek: "Miércoles", startTime: "09:00", endTime: "18:00", isActive: true),
        ProAvailabilitySlot(id: UUID(), dayOfWeek: "Jueves", startTime: "09:00", endTime: "20:00", isActive: true),
        ProAvailabilitySlot(id: UUID(), dayOfWeek: "Viernes", startTime: "09:00", endTime: "18:00", isActive: true),
        ProAvailabilitySlot(id: UUID(), dayOfWeek: "Sábado", startTime: "10:00", endTime: "14:00", isActive: true),
        ProAvailabilitySlot(id: UUID(), dayOfWeek: "Domingo", startTime: "—", endTime: "—", isActive: false)
    ]

    private static let menuId1 = UUID()
    private static let menuId2 = UUID()
    private static let menuId3 = UUID()
    private static let menuId4 = UUID()
    private static let menuId5 = UUID()
    private static let menuId6 = UUID()
    private static let menuId7 = UUID()
    private static let menuId8 = UUID()

    static let profileMenuItems: [ProProfileMenuItem] = [
        ProProfileMenuItem(id: menuId1, section: .datos, title: "Datos personales", icon: "person.text.rectangle", color: .indigo),
        ProProfileMenuItem(id: menuId2, section: .misServicios, title: "Mis servicios", icon: "wrench.and.screwdriver.fill", color: .orange),
        ProProfileMenuItem(id: menuId3, section: .zonas, title: "Zonas de cobertura", icon: "map.fill", color: .mint),
        ProProfileMenuItem(id: menuId4, section: .disponibilidad, title: "Disponibilidad", icon: "calendar.badge.clock", color: .blue),
        ProProfileMenuItem(id: menuId5, section: .datosBancarios, title: "Datos bancarios", icon: "creditcard.fill", color: .purple),
        ProProfileMenuItem(id: menuId6, section: .estadisticas, title: "Estadísticas y reseñas", icon: "chart.bar.fill", color: .green),
        ProProfileMenuItem(id: menuId7, section: .soporte, title: "Ayuda y soporte", icon: "questionmark.circle.fill", color: .cyan),
        ProProfileMenuItem(id: menuId8, section: .privacidad, title: "Privacidad y seguridad", icon: "shield.checkerboard", color: .red)
    ]
}
