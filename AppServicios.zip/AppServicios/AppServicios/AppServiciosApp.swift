//
//  AppServiciosApp.swift
//  AppServicios
//
//  Created by Francisco Martín on 26/02/2026.
//

import SwiftUI

@main
struct AppServiciosApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
