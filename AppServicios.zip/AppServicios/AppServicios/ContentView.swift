//
//  ContentView.swift
//  AppServicios
//
//  Created by Francisco Martín on 26/02/2026.
//

import SwiftUI

struct ContentView: View {
    @State private var selectedTab: MainMockTab = .inicio

    private let categories = ["Todos", "Plomería", "Electricidad", "Limpieza", "Pintura", "Jardinería", "Tecnología"]
    private let quickFilters = [
        "📍 Cerca de mí",
        "💸 Hasta $25.000",
        "⭐ 4.5+",
        "🕒 Hoy",
        "🚗 A domicilio"
    ]

    private let professionals: [ProfessionalCardData] = [
        ProfessionalCardData(
            name: "Carlos Méndez",
            jobTitle: "Electricista matriculado",
            rating: 4.9,
            reviews: 214,
            distance: "1.2 km",
            price: "Desde $18.000",
            availability: "Disponible hoy 16:00",
            tags: ["Urgencias", "Instalaciones", "Garantía"],
            image: "bolt.fill",
            accent: .yellow
        ),
        ProfessionalCardData(
            name: "Sofía Rojas",
            jobTitle: "Plomería y gas",
            rating: 4.8,
            reviews: 172,
            distance: "2.4 km",
            price: "Desde $22.000",
            availability: "Disponible mañana",
            tags: ["24 hs", "Reparaciones", "Presupuesto"],
            image: "wrench.and.screwdriver.fill",
            accent: .blue
        ),
        ProfessionalCardData(
            name: "Mateo Díaz",
            jobTitle: "Limpieza de hogares y oficinas",
            rating: 4.7,
            reviews: 98,
            distance: "0.9 km",
            price: "Desde $14.500",
            availability: "Disponible hoy 18:30",
            tags: ["Eco friendly", "Puntualidad", "Con insumos"],
            image: "sparkles",
            accent: .mint
        )
    ]

    var body: some View {
        TabView(selection: $selectedTab) {
            HomeMockView()
                .tabItem {
                    Label("Inicio", systemImage: "house.fill")
                }
                .tag(MainMockTab.inicio)

            ExploreMockView()
                .tabItem {
                    Label("Explorar", systemImage: "magnifyingglass.circle.fill")
                }
                .tag(MainMockTab.explorar)

            ReservationsMockView()
                .tabItem {
                    Label("Reservas", systemImage: "calendar.badge.clock")
                }
                .tag(MainMockTab.reservas)

            ProfileMockView()
                .tabItem {
                    Label("Perfil", systemImage: "person.crop.circle")
                }
                .tag(MainMockTab.perfil)
        }
    }

    private var headerSection: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Hola, Francisco 👋")
                        .font(.system(size: 24, weight: .bold))
                    Text("Encontrá profesionales cerca tuyo")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                Button {
                    // Maqueta: sin acción real.
                } label: {
                    ZStack {
                        Circle()
                            .fill(.white)
                            .frame(width: 42, height: 42)
                        Image(systemName: "bell.badge.fill")
                            .foregroundStyle(.indigo)
                    }
                    .shadow(color: .black.opacity(0.08), radius: 8, y: 4)
                }
            }
        }
    }

    private var searchSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass")
                    .foregroundStyle(.secondary)
                Text("Buscar: plomero, electricista, limpieza...")
                    .foregroundStyle(.secondary)
                Spacer()
                Image(systemName: "slider.horizontal.3")
                    .foregroundStyle(.indigo)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
            .background(.white, in: RoundedRectangle(cornerRadius: 14))
            .shadow(color: .black.opacity(0.06), radius: 8, y: 4)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(quickFilters, id: \.self) { filter in
                        Text(filter)
                            .font(.caption.weight(.semibold))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(.white, in: Capsule())
                            .overlay(
                                Capsule()
                                    .stroke(.indigo.opacity(0.2), lineWidth: 1)
                            )
                    }
                }
            }
        }
    }

    private var categorySection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Filtrar por tipo de servicio")
                .font(.headline)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(categories.indices, id: \.self) { idx in
                        let isSelected = idx == 0
                        Text(categories[idx])
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(isSelected ? .white : .primary)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 10)
                            .background(
                                isSelected ? AnyShapeStyle(.indigo) : AnyShapeStyle(.white),
                                in: Capsule()
                            )
                            .overlay(
                                Capsule()
                                    .stroke(.indigo.opacity(isSelected ? 0 : 0.2), lineWidth: 1)
                            )
                    }
                }
            }
        }
    }

    private var mapPreviewSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Ubicación y zonas")
                    .font(.headline)
                Spacer()
                Text("Ver mapa completo")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.indigo)
            }

            ZStack {
                RoundedRectangle(cornerRadius: 18)
                    .fill(
                        LinearGradient(
                            colors: [.indigo.opacity(0.18), .cyan.opacity(0.14)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(height: 145)

                VStack(spacing: 10) {
                    Image(systemName: "map.fill")
                        .font(.system(size: 28))
                        .foregroundStyle(.indigo)
                    Text("CABA • Palermo, Belgrano, Recoleta")
                        .font(.subheadline.weight(.semibold))
                    Text("128 profesionales disponibles ahora")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private var featuredSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Profesionales recomendados")
                    .font(.headline)
                Spacer()
                Text("Ordenado por: relevancia")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            ForEach(professionals) { professional in
                ProfessionalCardView(data: professional)
            }
        }
    }

    private var bottomBar: some View {
        HStack(spacing: 22) {
            BottomBarItem(icon: "house.fill", title: "Inicio", active: true)
            BottomBarItem(icon: "magnifyingglass.circle.fill", title: "Explorar", active: false)
            BottomBarItem(icon: "calendar.badge.clock", title: "Reservas", active: false)
            BottomBarItem(icon: "person.crop.circle", title: "Perfil", active: false)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 12)
        .frame(maxWidth: .infinity)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22))
        .padding(.horizontal, 14)
        .padding(.bottom, 6)
    }
}

private struct ProfessionalCardData: Identifiable {
    let id = UUID()
    let name: String
    let jobTitle: String
    let rating: Double
    let reviews: Int
    let distance: String
    let price: String
    let availability: String
    let tags: [String]
    let image: String
    let accent: Color
}

private struct ProfessionalCardView: View {
    let data: ProfessionalCardData

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top, spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(data.accent.opacity(0.18))
                        .frame(width: 52, height: 52)
                    Image(systemName: data.image)
                        .font(.system(size: 20))
                        .foregroundStyle(data.accent)
                }

                VStack(alignment: .leading, spacing: 3) {
                    Text(data.name)
                        .font(.headline)
                    Text(data.jobTitle)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)

                    HStack(spacing: 8) {
                        Label("\(String(format: "%.1f", data.rating))", systemImage: "star.fill")
                            .foregroundStyle(.orange)
                        Text("(\(data.reviews) reseñas)")
                            .foregroundStyle(.secondary)
                        Text("• \(data.distance)")
                            .foregroundStyle(.secondary)
                    }
                    .font(.caption)
                }
                Spacer()
            }

            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(data.price)
                        .font(.subheadline.weight(.bold))
                    Text(data.availability)
                        .font(.caption)
                        .foregroundStyle(.green)
                }
                Spacer()
                Button {
                    // Maqueta: sin acción real.
                } label: {
                    Text("Ver perfil")
                        .font(.caption.weight(.bold))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(.indigo, in: Capsule())
                        .foregroundStyle(.white)
                }
            }

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 6) {
                    ForEach(data.tags, id: \.self) { tag in
                        Text(tag)
                            .font(.caption2.weight(.medium))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(data.accent.opacity(0.14), in: Capsule())
                    }
                }
            }
        }
        .padding(14)
        .background(.white, in: RoundedRectangle(cornerRadius: 16))
        .shadow(color: .black.opacity(0.06), radius: 10, y: 5)
    }
}

private struct BottomBarItem: View {
    let icon: String
    let title: String
    let active: Bool

    var body: some View {
        VStack(spacing: 4) {
            Image(systemName: icon)
                .font(.system(size: 18, weight: .semibold))
            Text(title)
                .font(.caption2)
        }
        .foregroundStyle(active ? .indigo : .secondary)
        .frame(maxWidth: .infinity)
    }
}

private enum MainMockTab {
    case inicio
    case explorar
    case reservas
    case perfil
}

private struct HomeMockView: View {
    @State private var showNotifications = false
    private let professionals = MockSeed.professionals
    private let notices = MockSeed.notifications

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Hola, Francisco 👋")
                            .font(.system(size: 28, weight: .bold))
                        Text("Encontrá y reservá profesionales de forma rápida.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }

                    topPanel
                    mapPreview
                    notificationsPreview

                    Text("Profesionales recomendados")
                        .font(.headline)

                    ForEach(professionals) { pro in
                        ProfessionalLinkCard(professional: pro)
                    }
                }
                .padding(16)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Inicio")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showNotifications = true
                    } label: {
                        ZStack(alignment: .topTrailing) {
                            Image(systemName: "bell.fill")
                                .font(.title3)
                                .frame(width: 22, height: 22)
                            Circle()
                                .fill(.red)
                                .frame(width: 9, height: 9)
                                .overlay(
                                    Circle()
                                        .stroke(Color(uiColor: .systemBackground), lineWidth: 1.2)
                                )
                                .offset(x: 4, y: -4)
                        }
                        .foregroundStyle(.indigo)
                    }
                }
            }
            .sheet(isPresented: $showNotifications) {
                NotificationsPanelView(notifications: notices)
            }
        }
    }

    private var topPanel: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Panel de inicio")
                .font(.headline)
            Text("2 reservas hoy • 3 notificaciones nuevas • 128 profesionales cerca.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            HStack(spacing: 8) {
                PanelBadge(title: "Reservas", value: "2", color: .indigo)
                PanelBadge(title: "Alertas", value: "3", color: .orange)
                PanelBadge(title: "Disponibles", value: "128", color: .mint)
            }
        }
        .padding(14)
        .background(
            LinearGradient(
                colors: [.indigo.opacity(0.22), .cyan.opacity(0.14)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ),
            in: RoundedRectangle(cornerRadius: 16)
        )
    }

    private var mapPreview: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Mapa de ubicación y zonas")
                    .font(.headline)
                Spacer()
                NavigationLink("Abrir mapa") {
                    MapZonesMockView(pins: MockSeed.pins)
                }
                .font(.caption.weight(.bold))
                .foregroundStyle(.indigo)
            }
            ZStack {
                RoundedRectangle(cornerRadius: 16)
                    .fill(Color(uiColor: .secondarySystemBackground))
                    .frame(height: 160)
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(Color.primary.opacity(0.08), lineWidth: 1)
                    )

                ForEach(MockSeed.pins) { pin in
                    PinTagView(pin: pin)
                        .offset(x: pin.xOffset, y: pin.yOffset)
                }
            }
        }
    }

    private var notificationsPreview: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Notificaciones")
                    .font(.headline)
                Spacer()
                Button("Ver todas") {
                    showNotifications = true
                }
                .font(.caption.weight(.bold))
            }
            ForEach(notices.prefix(2)) { notice in
                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: notice.icon)
                        .foregroundStyle(notice.color)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(notice.title)
                            .font(.subheadline.weight(.semibold))
                        Text(notice.message)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Text(notice.time)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                .padding(10)
                .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
            }
        }
    }
}

private struct ExploreMockView: View {
    private let professionals = MockSeed.professionals
    private let featuredServices = MockSeed.featuredServices

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("Filtrá por tipo de servicio, ubicación, precio y disponibilidad.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)

                    FilterChipsView(items: [
                        "Tipo: Plomería",
                        "Ubicación: Palermo",
                        "Precio: $10k-$30k",
                        "Calificación 4.5+",
                        "Disponible hoy",
                        "A domicilio"
                    ])

                    NavigationLink {
                        MapZonesMockView(pins: MockSeed.pins)
                    } label: {
                        ZStack {
                            RoundedRectangle(cornerRadius: 16)
                                .fill(
                                    LinearGradient(
                                        colors: [.indigo.opacity(0.2), .cyan.opacity(0.13)],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .frame(height: 140)
                            VStack(spacing: 6) {
                                Image(systemName: "map.fill")
                                    .font(.title2)
                                Text("Ver mapa por zonas")
                                    .font(.headline)
                                Text("Con punteros de profesionales disponibles")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    .buttonStyle(.plain)

                    HStack {
                        Text("Servicios destacados")
                            .font(.headline)
                        Spacer()
                        NavigationLink("Ver servicios") {
                            ServiceCatalogMockView(services: featuredServices, title: "Servicios")
                        }
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.indigo)
                    }

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(featuredServices.prefix(6)) { service in
                                NavigationLink {
                                    ServiceDetailMockView(service: service)
                                } label: {
                                    ServicePhotoCardView(service: service)
                                }
                                .buttonStyle(.plain)
                                .frame(width: 220)
                            }
                        }
                    }

                    Text("Resultados")
                        .font(.headline)

                    ForEach(professionals) { pro in
                        ProfessionalLinkCard(professional: pro)
                    }
                }
                .padding(16)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Explorar")
        }
    }
}

private struct ReservationsMockView: View {
    var body: some View {
        NavigationStack {
            List {
                Section("Próximas") {
                    ForEach(MockSeed.reservations) { item in
                        NavigationLink {
                            ReservationDetailView(item: item)
                        } label: {
                            ReservationRowView(item: item)
                        }
                    }
                }

                Section("En curso") {
                    ForEach(MockSeed.activeReservations) { item in
                        NavigationLink {
                            ReservationDetailView(item: item)
                        } label: {
                            ReservationRowView(item: item)
                        }
                    }
                }

                Section("Historial") {
                    ForEach(MockSeed.pastReservations) { item in
                        NavigationLink {
                            ReservationDetailView(item: item)
                        } label: {
                            ReservationRowView(item: item)
                        }
                    }
                }
            }
            .navigationTitle("Reservas")
        }
    }
}

private struct ProfileMockView: View {
    private let userAvatarURL = "https://i.pravatar.cc/300?img=12"
    private let menu: [ProfileMenuItem] = [
        ProfileMenuItem(section: .datos, title: "Datos personales", icon: "person.text.rectangle", color: .indigo),
        ProfileMenuItem(section: .direcciones, title: "Direcciones guardadas", icon: "mappin.and.ellipse", color: .orange),
        ProfileMenuItem(section: .pagos, title: "Métodos de pago", icon: "creditcard.fill", color: .mint),
        ProfileMenuItem(section: .historial, title: "Historial de servicios", icon: "clock.arrow.trianglehead.counterclockwise.rotate.90", color: .purple),
        ProfileMenuItem(section: .soporte, title: "Ayuda y soporte", icon: "questionmark.circle.fill", color: .blue),
        ProfileMenuItem(section: .privacidad, title: "Privacidad y seguridad", icon: "shield.checkerboard", color: .green)
    ]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 14) {
                    VStack(spacing: 8) {
                        AvatarImageView(urlString: userAvatarURL, size: 86)
                        Text("Francisco Martín")
                            .font(.title3.weight(.bold))
                        Text("Cuenta cliente verificada")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 16))

                    ForEach(menu) { item in
                        NavigationLink {
                            ProfileSubmenuDetailView(item: item)
                        } label: {
                            ProfileRow(title: item.title, icon: item.icon, color: item.color)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(16)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Perfil")
        }
    }
}

private struct MapZonesMockView: View {
    let pins: [MockPin]

    var body: some View {
        VStack(spacing: 12) {
            ZStack {
                LinearGradient(
                    colors: [.cyan.opacity(0.24), .indigo.opacity(0.18)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .overlay(MapExampleBackground().opacity(0.45))
                .clipShape(RoundedRectangle(cornerRadius: 18))
                .padding(.horizontal, 16)
                .padding(.top, 10)

                ForEach(pins) { pin in
                    PinTagView(pin: pin)
                        .offset(x: pin.xOffset * 1.2, y: pin.yOffset * 1.05)
                }
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("Ejemplo de mapa")
                    .font(.headline)
                Text("Zonas activas: Palermo • Belgrano • Recoleta • Caballito")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                HStack(spacing: 8) {
                    LegendChip(text: "Disponible ahora", color: .green)
                    LegendChip(text: "Llega en 30-60 min", color: .orange)
                    LegendChip(text: "Con agenda", color: .indigo)
                }
            }
            .padding(.horizontal, 16)

            Spacer(minLength: 0)
        }
        .background(Color(.systemGroupedBackground).ignoresSafeArea())
        .navigationTitle("Mapa y zonas")
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct NotificationsPanelView: View {
    let notifications: [MockNotification]

    var body: some View {
        NavigationStack {
            List {
                Section("No leídas") {
                    ForEach(notifications.filter { !$0.isRead }) { notice in
                        NavigationLink {
                            NotificationDetailView(notice: notice)
                        } label: {
                            NotificationRowView(notice: notice)
                        }
                    }
                }

                Section("Anteriores") {
                    ForEach(notifications.filter { $0.isRead }) { notice in
                        NavigationLink {
                            NotificationDetailView(notice: notice)
                        } label: {
                            NotificationRowView(notice: notice)
                        }
                    }
                }
            }
            .navigationTitle("Notificaciones")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Marcar todo leído") {
                        // Maqueta: sin acción real.
                    }
                    .font(.caption.weight(.semibold))
                }
            }
        }
    }
}

private struct ProfessionalLinkCard: View {
    let professional: MockProfessional

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 10) {
                AvatarImageView(urlString: professional.avatarURL, size: 52)

                VStack(alignment: .leading, spacing: 3) {
                    Text(professional.name)
                        .font(.headline)
                    Text(professional.title)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Text(professional.experience)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Label("\(String(format: "%.1f", professional.rating))", systemImage: "star.fill")
                    .font(.caption)
                    .foregroundStyle(.orange)
            }

            HStack {
                Text(professional.price)
                    .font(.subheadline.weight(.bold))
                Text("• \(professional.distance)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                NavigationLink("Ver perfil") {
                    ProfessionalProfileMockView(professional: professional)
                }
                .font(.caption.weight(.bold))
                .foregroundStyle(.white)
                .padding(.horizontal, 10)
                .padding(.vertical, 7)
                .background(.indigo, in: Capsule())
            }
            Text(professional.bio)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(2)
            FilterChipsView(items: professional.tags)
        }
        .padding(12)
        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 14))
        .shadow(color: .black.opacity(0.03), radius: 8, y: 4)
    }
}

private struct ProfessionalProfileMockView: View {
    let professional: MockProfessional

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                VStack(spacing: 10) {
                    AvatarImageView(urlString: professional.avatarURL, size: 94)
                    Text(professional.name)
                        .font(.title3.weight(.bold))
                    Text(professional.title)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    HStack(spacing: 10) {
                        Label("\(String(format: "%.1f", professional.rating))", systemImage: "star.fill")
                            .foregroundStyle(.orange)
                        Text("\(professional.reviews) reseñas")
                            .foregroundStyle(.secondary)
                        Text("• \(professional.distance)")
                            .foregroundStyle(.secondary)
                    }
                    .font(.caption)
                }
                .frame(maxWidth: .infinity)
                .padding(14)
                .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))

                HStack(spacing: 8) {
                    DetailStatCard(title: "Trabajos", value: "\(professional.completedJobs)", color: .indigo)
                    DetailStatCard(title: "Responde", value: professional.responseTime, color: .mint)
                    DetailStatCard(title: "Experiencia", value: professional.experience, color: .orange)
                }

                GroupBox("Información") {
                    VStack(alignment: .leading, spacing: 8) {
                        Label(professional.price, systemImage: "banknote")
                        Label("Distancia aproximada: \(professional.distance)", systemImage: "location")
                        Label("Disponibilidad: \(professional.availability)", systemImage: "clock")
                    }
                }

                GroupBox("Sobre el profesional") {
                    Text(professional.bio)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                GroupBox("Zonas de servicio") {
                    FilterChipsView(items: professional.serviceAreas)
                }

                Text("Especialidades")
                    .font(.headline)
                FilterChipsView(items: professional.tags)

                NavigationLink {
                    ServiceCatalogMockView(services: professional.services, title: "Servicios de \(professional.name)")
                } label: {
                    HStack {
                        Text("Ver servicios y fotos")
                            .font(.subheadline.weight(.bold))
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.caption.weight(.bold))
                    }
                    .padding(12)
                    .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
                }
                .buttonStyle(.plain)

                Text("Trabajos recientes")
                    .font(.headline)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(professional.services.prefix(4)) { service in
                            NavigationLink {
                                ServiceDetailMockView(service: service)
                            } label: {
                                ServicePhotoCardView(service: service)
                            }
                            .buttonStyle(.plain)
                            .frame(width: 210)
                        }
                    }
                }

                HStack(spacing: 10) {
                    Button("Contactar") {}
                        .buttonStyle(.bordered)
                    Button("Reservar ahora") {}
                        .buttonStyle(.borderedProminent)
                }
            }
            .padding(16)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Ver perfil")
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct ServiceCatalogMockView: View {
    let services: [MockService]
    let title: String

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                Text("Elegí un servicio para ver detalles, fotos, duración e información.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)

                ForEach(services) { service in
                    NavigationLink {
                        ServiceDetailMockView(service: service)
                    } label: {
                        ServiceListRowView(service: service)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(16)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct ServiceDetailMockView: View {
    let service: MockService

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                ServiceHeroImageView(urlString: service.imageURL)

                VStack(alignment: .leading, spacing: 6) {
                    Text(service.title)
                        .font(.title3.weight(.bold))
                    Text(service.category)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    HStack(spacing: 10) {
                        Label(service.startingPrice, systemImage: "banknote")
                        Label(service.duration, systemImage: "clock")
                        Label("\(String(format: "%.1f", service.rating))", systemImage: "star.fill")
                            .foregroundStyle(.orange)
                    }
                    .font(.caption)
                }
                .padding(12)
                .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))

                GroupBox("Descripción del servicio") {
                    Text(service.description)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                GroupBox("Incluye") {
                    VStack(alignment: .leading, spacing: 8) {
                        ForEach(service.includes, id: \.self) { item in
                            Label(item, systemImage: "checkmark.circle.fill")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                }

                Text("Fotos del servicio")
                    .font(.headline)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(service.galleryImageURLs, id: \.self) { url in
                            ServiceGalleryThumbView(urlString: url)
                                .frame(width: 180, height: 120)
                        }
                    }
                }

                Button("Solicitar este servicio") {}
                    .buttonStyle(.borderedProminent)
            }
            .padding(16)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Detalle servicio")
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct ServicePhotoCardView: View {
    let service: MockService

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ServiceGalleryThumbView(urlString: service.imageURL)
                .frame(height: 128)

            Text(service.title)
                .font(.subheadline.weight(.bold))
                .lineLimit(2)
            Text(service.category)
                .font(.caption)
                .foregroundStyle(.secondary)
            HStack {
                Text(service.startingPrice)
                    .font(.caption.weight(.bold))
                Spacer()
                Label("\(String(format: "%.1f", service.rating))", systemImage: "star.fill")
                    .font(.caption2)
                    .foregroundStyle(.orange)
            }
        }
        .padding(10)
        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
    }
}

private struct ServiceListRowView: View {
    let service: MockService

    var body: some View {
        HStack(spacing: 10) {
            ServiceGalleryThumbView(urlString: service.imageURL)
                .frame(width: 96, height: 72)

            VStack(alignment: .leading, spacing: 4) {
                Text(service.title)
                    .font(.subheadline.weight(.bold))
                    .lineLimit(2)
                Text(service.category)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                HStack(spacing: 8) {
                    Text(service.startingPrice)
                        .font(.caption.weight(.semibold))
                    Text("•")
                        .foregroundStyle(.secondary)
                    Text(service.duration)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            Spacer()
            Image(systemName: "chevron.right")
                .font(.caption.weight(.bold))
                .foregroundStyle(.secondary)
        }
        .padding(10)
        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
    }
}

private struct ServiceHeroImageView: View {
    let urlString: String

    var body: some View {
        AsyncImage(url: URL(string: urlString)) { phase in
            switch phase {
            case .success(let image):
                image
                    .resizable()
                    .scaledToFill()
            case .failure, .empty:
                ZStack {
                    LinearGradient(
                        colors: [.indigo.opacity(0.4), .cyan.opacity(0.3)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    Image(systemName: "photo.on.rectangle.angled")
                        .font(.system(size: 34))
                        .foregroundStyle(.white)
                }
            @unknown default:
                Color.gray.opacity(0.2)
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: 220)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

private struct ServiceGalleryThumbView: View {
    let urlString: String

    var body: some View {
        AsyncImage(url: URL(string: urlString)) { phase in
            switch phase {
            case .success(let image):
                image
                    .resizable()
                    .scaledToFill()
            case .failure, .empty:
                ZStack {
                    Color(uiColor: .tertiarySystemBackground)
                    Image(systemName: "photo")
                        .foregroundStyle(.secondary)
                }
            @unknown default:
                Color.gray.opacity(0.2)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}

private struct FilterChipsView: View {
    let items: [String]

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(items, id: \.self) { item in
                    Text(item)
                        .font(.caption.weight(.semibold))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 7)
                        .background(Color(uiColor: .tertiarySystemBackground), in: Capsule())
                        .overlay(
                            Capsule()
                                .stroke(Color.primary.opacity(0.12), lineWidth: 1)
                        )
                }
            }
        }
    }
}

private struct PinTagView: View {
    let pin: MockPin

    var body: some View {
        VStack(spacing: 3) {
            Image(systemName: "mappin.circle.fill")
                .font(.title2)
                .foregroundStyle(pin.color)
            Text(pin.name)
                .font(.caption2.weight(.bold))
                .padding(.horizontal, 7)
                .padding(.vertical, 3)
                .background(.regularMaterial, in: Capsule())
        }
    }
}

private struct PanelBadge: View {
    let title: String
    let value: String
    let color: Color

    var body: some View {
        VStack(spacing: 2) {
            Text(value)
                .font(.headline.weight(.bold))
            Text(title)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 8)
        .frame(maxWidth: .infinity)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 10))
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(color.opacity(0.25), lineWidth: 1)
        )
    }
}

private struct ProfileRow: View {
    let title: String
    let icon: String
    let color: Color

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(color)
                .frame(width: 24)
            Text(title)
            Spacer()
            Image(systemName: "chevron.right")
                .font(.caption.weight(.bold))
                .foregroundStyle(.secondary)
        }
        .padding(14)
        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
    }
}

private struct ReservationRowView: View {
    let item: MockReservation

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(item.professional)
                .font(.headline)
            Text(item.service)
                .font(.subheadline)
                .foregroundStyle(.secondary)
            HStack {
                Label(item.date, systemImage: "calendar")
                Label(item.time, systemImage: "clock")
            }
            .font(.caption)
            .foregroundStyle(.secondary)
            HStack {
                Text(item.status)
                    .font(.caption.weight(.semibold))
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(item.color.opacity(0.2), in: Capsule())
                Spacer()
                Text(item.price)
                    .font(.subheadline.weight(.bold))
            }
        }
        .padding(.vertical, 4)
    }
}

private struct ReservationDetailView: View {
    let item: MockReservation

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                GroupBox("Detalle de la reserva") {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(item.professional)
                            .font(.headline)
                        Text(item.service)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Label("\(item.date) • \(item.time)", systemImage: "calendar.badge.clock")
                        Label(item.address, systemImage: "mappin.and.ellipse")
                        Label("Pago: \(item.paymentMethod)", systemImage: "creditcard")
                    }
                }

                GroupBox("Estado y acciones") {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(item.status)
                            .font(.subheadline.weight(.bold))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(item.color.opacity(0.2), in: Capsule())
                        Text("Precio estimado: \(item.price)")
                            .font(.subheadline)
                        HStack(spacing: 8) {
                            Button("Reprogramar") {}
                                .buttonStyle(.bordered)
                            Button("Contactar") {}
                                .buttonStyle(.borderedProminent)
                        }
                    }
                }
            }
            .padding(16)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Detalle de reserva")
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct ProfileMenuItem: Identifiable {
    let id = UUID()
    let section: ProfileSection
    let title: String
    let icon: String
    let color: Color
}

private enum ProfileSection {
    case datos
    case direcciones
    case pagos
    case historial
    case soporte
    case privacidad
}

private struct ProfileSubmenuDetailView: View {
    let item: ProfileMenuItem

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 10) {
                    Image(systemName: item.icon)
                        .foregroundStyle(item.color)
                        .font(.title2)
                    Text(item.title)
                        .font(.title3.weight(.bold))
                }

                switch item.section {
                case .datos:
                    personalDataSection
                case .direcciones:
                    addressesSection
                case .pagos:
                    paymentMethodsSection
                case .historial:
                    serviceHistorySection
                case .soporte:
                    supportSection
                case .privacidad:
                    privacySection
                }
            }
            .padding(16)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle(item.title)
        .navigationBarTitleDisplayMode(.inline)
    }

    private var personalDataSection: some View {
        VStack(spacing: 12) {
            GroupBox("Información personal") {
                VStack(alignment: .leading, spacing: 10) {
                    ProfileInfoRow(label: "Nombre", value: "Francisco Martín")
                    ProfileInfoRow(label: "Correo", value: "francisco.martin@email.com")
                    ProfileInfoRow(label: "Teléfono", value: "+54 11 6789 1234")
                    ProfileInfoRow(label: "Documento", value: "DNI verificado")
                    ProfileInfoRow(label: "Miembro desde", value: "Enero 2024")
                }
            }

            GroupBox("Preferencias de cuenta") {
                VStack(alignment: .leading, spacing: 8) {
                    Label("Idioma preferido: Español", systemImage: "globe")
                    Label("Notificaciones push activas", systemImage: "bell.fill")
                    Label("Comprobantes por correo: Activado", systemImage: "envelope.badge.fill")
                }
                .font(.subheadline)
                .foregroundStyle(.secondary)
            }
        }
    }

    private var addressesSection: some View {
        VStack(spacing: 12) {
            GroupBox("Direcciones guardadas") {
                VStack(spacing: 10) {
                    ForEach(addresses, id: \.nickname) { address in
                        UserAddressCard(address: address)
                    }
                }
            }

            GroupBox("Cobertura y zonas") {
                VStack(alignment: .leading, spacing: 8) {
                    Label("Zonas frecuentes: Palermo, Belgrano, Recoleta", systemImage: "map")
                    Label("Radio de búsqueda por defecto: 5 km", systemImage: "scope")
                    Label("Dirección principal para reservas rápidas: Casa", systemImage: "house.fill")
                }
                .font(.subheadline)
                .foregroundStyle(.secondary)
            }
        }
    }

    private var paymentMethodsSection: some View {
        VStack(spacing: 12) {
            GroupBox("Métodos de pago") {
                VStack(spacing: 10) {
                    ForEach(paymentMethods, id: \.name) { method in
                        PaymentMethodCard(method: method)
                    }
                }
            }

            GroupBox("Facturación y comprobantes") {
                VStack(alignment: .leading, spacing: 8) {
                    ProfileInfoRow(label: "Tipo de comprobante", value: "Factura B")
                    ProfileInfoRow(label: "CUIT/CUIL", value: "20-12345678-9")
                    ProfileInfoRow(label: "Correo de facturación", value: "facturacion@email.com")
                    ProfileInfoRow(label: "Auto-guardar comprobantes", value: "Activado")
                }
            }

            GroupBox("Acciones de pago") {
                HStack(spacing: 8) {
                    Button("Agregar tarjeta") {}
                        .buttonStyle(.borderedProminent)
                    Button("Configurar Wallet") {}
                        .buttonStyle(.bordered)
                }
            }
        }
    }

    private var serviceHistorySection: some View {
        VStack(spacing: 12) {
            GroupBox("Resumen del historial") {
                HStack(spacing: 8) {
                    DetailStatCard(title: "Servicios", value: "28", color: .indigo)
                    DetailStatCard(title: "Finalizados", value: "24", color: .green)
                    DetailStatCard(title: "Promedio", value: "4.8", color: .orange)
                }
            }

            GroupBox("Últimos servicios") {
                VStack(spacing: 10) {
                    ForEach(serviceHistory, id: \.title) { history in
                        ServiceHistoryCard(item: history)
                    }
                }
            }

            GroupBox("Preferencias de contratación") {
                VStack(alignment: .leading, spacing: 8) {
                    Label("Servicios más solicitados: Electricidad y Limpieza", systemImage: "chart.bar.fill")
                    Label("Frecuencia media: 3 servicios/mes", systemImage: "calendar")
                    Label("Horario preferido: 09:00 - 18:00", systemImage: "clock")
                }
                .font(.subheadline)
                .foregroundStyle(.secondary)
            }
        }
    }

    private var supportSection: some View {
        VStack(spacing: 12) {
            GroupBox("Canales de ayuda") {
                VStack(spacing: 10) {
                    SupportRow(icon: "message.fill", title: "Chat en vivo", subtitle: "Respuesta estimada: 2-5 min")
                    SupportRow(icon: "phone.fill", title: "Soporte telefónico", subtitle: "Lunes a sábado • 08:00-22:00")
                    SupportRow(icon: "envelope.fill", title: "Soporte por correo", subtitle: "soporte@appservicios.com")
                    SupportRow(icon: "questionmark.bubble.fill", title: "Centro de ayuda", subtitle: "Guías, preguntas frecuentes y políticas")
                }
            }

            GroupBox("Estado de tickets") {
                VStack(alignment: .leading, spacing: 8) {
                    ProfileInfoRow(label: "Abiertos", value: "1")
                    ProfileInfoRow(label: "En seguimiento", value: "2")
                    ProfileInfoRow(label: "Resueltos (últimos 90 días)", value: "7")
                }
            }

            GroupBox("Acciones rápidas") {
                HStack(spacing: 8) {
                    Button("Abrir nuevo ticket") {}
                        .buttonStyle(.borderedProminent)
                    Button("Ver FAQ") {}
                        .buttonStyle(.bordered)
                }
            }
        }
    }

    private var privacySection: some View {
        VStack(spacing: 12) {
            GroupBox("Seguridad de la cuenta") {
                VStack(alignment: .leading, spacing: 10) {
                    ProfileInfoRow(label: "Autenticación en dos pasos", value: "Activada")
                    ProfileInfoRow(label: "Sesiones activas", value: "2 dispositivos")
                    ProfileInfoRow(label: "Último acceso", value: "Hoy, 10:22 - iPhone")
                    ProfileInfoRow(label: "PIN de seguridad", value: "Configurado")
                }
            }

            GroupBox("Privacidad de datos") {
                VStack(alignment: .leading, spacing: 8) {
                    Label("Perfil visible solo para profesionales contratados", systemImage: "eye.slash.fill")
                    Label("Compartir ubicación exacta solo al reservar", systemImage: "location.slash.fill")
                    Label("Uso de datos para recomendaciones: Activado", systemImage: "brain.head.profile")
                    Label("Descarga de datos personales disponible", systemImage: "square.and.arrow.down.fill")
                }
                .font(.subheadline)
                .foregroundStyle(.secondary)
            }

            GroupBox("Acciones de seguridad") {
                HStack(spacing: 8) {
                    Button("Cambiar contraseña") {}
                        .buttonStyle(.borderedProminent)
                    Button("Cerrar sesiones") {}
                        .buttonStyle(.bordered)
                }
            }
        }
    }

    private var addresses: [UserAddress] {
        [
            UserAddress(
                nickname: "Casa",
                address: "Honduras 4231, Palermo, CABA",
                notes: "Timbre B • Portero hasta 20:00",
                isDefault: true
            ),
            UserAddress(
                nickname: "Trabajo",
                address: "Av. Libertador 2140, Belgrano, CABA",
                notes: "Recepción piso 4",
                isDefault: false
            ),
            UserAddress(
                nickname: "Departamento mamá",
                address: "French 2980, Recoleta, CABA",
                notes: "Coordinar visita con 2 h de anticipación",
                isDefault: false
            )
        ]
    }

    private var paymentMethods: [PaymentMethod] {
        [
            PaymentMethod(name: "Visa crédito", detail: "•••• 2314 • Vence 08/28", badge: "Predeterminada", badgeColor: .indigo),
            PaymentMethod(name: "Master débito", detail: "•••• 7880 • Vence 03/27", badge: "Activa", badgeColor: .mint),
            PaymentMethod(name: "Mercado Pago", detail: "Cuenta conectada", badge: "Wallet", badgeColor: .orange)
        ]
    }

    private var serviceHistory: [ServiceHistoryItem] {
        [
            ServiceHistoryItem(title: "Revisión de tablero eléctrico", date: "26 Feb 2026", proName: "Carlos Méndez", amount: "$18.000", status: "Finalizado", statusColor: .green),
            ServiceHistoryItem(title: "Reparación de pérdida en cocina", date: "22 Feb 2026", proName: "Sofía Rojas", amount: "$22.000", status: "Finalizado", statusColor: .green),
            ServiceHistoryItem(title: "Limpieza profunda", date: "18 Feb 2026", proName: "Mateo Díaz", amount: "$14.500", status: "Calificado", statusColor: .indigo)
        ]
    }
}

private struct ProfileInfoRow: View {
    let label: String
    let value: String

    var body: some View {
        HStack(alignment: .top) {
            Text(label)
                .foregroundStyle(.secondary)
            Spacer()
            Text(value)
                .multilineTextAlignment(.trailing)
                .fontWeight(.semibold)
        }
        .font(.subheadline)
    }
}

private struct UserAddress {
    let nickname: String
    let address: String
    let notes: String
    let isDefault: Bool
}

private struct UserAddressCard: View {
    let address: UserAddress

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(address.nickname)
                    .font(.subheadline.weight(.bold))
                if address.isDefault {
                    Text("Principal")
                        .font(.caption2.weight(.bold))
                        .padding(.horizontal, 7)
                        .padding(.vertical, 3)
                        .background(.indigo, in: Capsule())
                        .foregroundStyle(.white)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.secondary)
            }
            Text(address.address)
                .font(.subheadline)
            Text(address.notes)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(10)
        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 10))
    }
}

private struct PaymentMethod {
    let name: String
    let detail: String
    let badge: String
    let badgeColor: Color
}

private struct PaymentMethodCard: View {
    let method: PaymentMethod

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "creditcard.fill")
                .foregroundStyle(method.badgeColor)
                .frame(width: 24)
            VStack(alignment: .leading, spacing: 3) {
                Text(method.name)
                    .font(.subheadline.weight(.bold))
                Text(method.detail)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Text(method.badge)
                .font(.caption2.weight(.bold))
                .padding(.horizontal, 7)
                .padding(.vertical, 3)
                .background(method.badgeColor.opacity(0.18), in: Capsule())
        }
        .padding(10)
        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 10))
    }
}

private struct ServiceHistoryItem {
    let title: String
    let date: String
    let proName: String
    let amount: String
    let status: String
    let statusColor: Color
}

private struct ServiceHistoryCard: View {
    let item: ServiceHistoryItem

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(item.title)
                .font(.subheadline.weight(.bold))
            Text("Profesional: \(item.proName)")
                .font(.caption)
                .foregroundStyle(.secondary)
            HStack {
                Text(item.date)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Text(item.amount)
                    .font(.subheadline.weight(.bold))
            }
            Text(item.status)
                .font(.caption.weight(.semibold))
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(item.statusColor.opacity(0.18), in: Capsule())
        }
        .padding(10)
        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 10))
    }
}

private struct SupportRow: View {
    let icon: String
    let title: String
    let subtitle: String

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .foregroundStyle(.indigo)
                .frame(width: 24)
            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.subheadline.weight(.bold))
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding(10)
        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 10))
    }
}

private struct NotificationRowView: View {
    let notice: MockNotification

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: notice.icon)
                .foregroundStyle(notice.color)
                .font(.title3)
                .frame(width: 24)
            VStack(alignment: .leading, spacing: 4) {
                Text(notice.title)
                    .font(.headline)
                Text(notice.message)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                HStack {
                    Text(notice.time)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                    if !notice.isRead {
                        Text("Nueva")
                            .font(.caption2.weight(.bold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(.indigo, in: Capsule())
                    }
                }
            }
        }
        .padding(.vertical, 4)
    }
}

private struct NotificationDetailView: View {
    let notice: MockNotification

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 10) {
                    Image(systemName: notice.icon)
                        .font(.title2)
                        .foregroundStyle(notice.color)
                    Text(notice.title)
                        .font(.title3.weight(.bold))
                }
                Text(notice.message)
                    .font(.body)
                Text("Recibida: \(notice.time)")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                GroupBox("Acciones") {
                    HStack(spacing: 8) {
                        Button("Ir al detalle") {}
                            .buttonStyle(.borderedProminent)
                        Button("Descartar") {}
                            .buttonStyle(.bordered)
                    }
                }
            }
            .padding(16)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Detalle notificación")
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct LegendChip: View {
    let text: String
    let color: Color

    var body: some View {
        HStack(spacing: 6) {
            Circle()
                .fill(color)
                .frame(width: 8, height: 8)
            Text(text)
                .font(.caption2.weight(.semibold))
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 5)
        .background(.regularMaterial, in: Capsule())
    }
}

private struct MapExampleBackground: View {
    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        GeometryReader { geo in
            ZStack {
                RoundedRectangle(cornerRadius: 18)
                    .fill(
                        LinearGradient(
                            colors: gradientColors,
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )

                Path { path in
                    let w = geo.size.width
                    let h = geo.size.height
                    path.move(to: CGPoint(x: 0.1 * w, y: 0.2 * h))
                    path.addLine(to: CGPoint(x: 0.9 * w, y: 0.25 * h))
                    path.move(to: CGPoint(x: 0.05 * w, y: 0.55 * h))
                    path.addLine(to: CGPoint(x: 0.8 * w, y: 0.6 * h))
                    path.move(to: CGPoint(x: 0.2 * w, y: 0.85 * h))
                    path.addLine(to: CGPoint(x: 0.95 * w, y: 0.8 * h))
                    path.move(to: CGPoint(x: 0.25 * w, y: 0.05 * h))
                    path.addLine(to: CGPoint(x: 0.3 * w, y: 0.95 * h))
                    path.move(to: CGPoint(x: 0.55 * w, y: 0.1 * h))
                    path.addLine(to: CGPoint(x: 0.62 * w, y: 0.9 * h))
                }
                .stroke(roadColor, style: StrokeStyle(lineWidth: 3, lineCap: .round))

                RoundedRectangle(cornerRadius: 12)
                    .fill(.green.opacity(0.2))
                    .frame(width: geo.size.width * 0.26, height: geo.size.height * 0.18)
                    .offset(x: -geo.size.width * 0.22, y: geo.size.height * 0.22)

                RoundedRectangle(cornerRadius: 12)
                    .fill(.orange.opacity(0.2))
                    .frame(width: geo.size.width * 0.24, height: geo.size.height * 0.16)
                    .offset(x: geo.size.width * 0.24, y: -geo.size.height * 0.22)
            }
        }
        .frame(height: 360)
    }

    private var gradientColors: [Color] {
        colorScheme == .dark
            ? [Color.white.opacity(0.14), Color.white.opacity(0.04)]
            : [Color.white.opacity(0.3), Color.white.opacity(0.05)]
    }

    private var roadColor: Color {
        colorScheme == .dark ? Color.white.opacity(0.45) : Color.white.opacity(0.8)
    }
}

private struct AvatarImageView: View {
    let urlString: String
    let size: CGFloat

    var body: some View {
        AsyncImage(url: URL(string: urlString)) { phase in
            switch phase {
            case .success(let image):
                image
                    .resizable()
                    .scaledToFill()
            case .failure, .empty:
                ZStack {
                    LinearGradient(
                        colors: [.indigo.opacity(0.5), .cyan.opacity(0.35)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    Image(systemName: "person.fill")
                        .foregroundStyle(.white)
                        .font(.system(size: size * 0.35))
                }
            @unknown default:
                Color.gray.opacity(0.2)
            }
        }
        .frame(width: size, height: size)
        .clipShape(Circle())
        .overlay(
            Circle()
                .stroke(Color(uiColor: .systemBackground), lineWidth: 2)
        )
        .shadow(color: .black.opacity(0.12), radius: 8, y: 4)
    }
}

private struct DetailStatCard: View {
    let title: String
    let value: String
    let color: Color

    var body: some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.subheadline.weight(.bold))
            Text(title)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
        .background(color.opacity(0.12), in: RoundedRectangle(cornerRadius: 10))
    }
}

private struct MockProfessional: Identifiable {
    let id = UUID()
    let name: String
    let title: String
    let avatarURL: String
    let rating: Double
    let reviews: Int
    let price: String
    let distance: String
    let availability: String
    let experience: String
    let responseTime: String
    let completedJobs: Int
    let bio: String
    let tags: [String]
    let serviceAreas: [String]
    let services: [MockService]
}

private struct MockService: Identifiable {
    let id = UUID()
    let title: String
    let category: String
    let startingPrice: String
    let duration: String
    let rating: Double
    let description: String
    let imageURL: String
    let galleryImageURLs: [String]
    let includes: [String]
}

private struct MockReservation: Identifiable {
    let id = UUID()
    let professional: String
    let service: String
    let date: String
    let time: String
    let status: String
    let color: Color
    let price: String
    let address: String
    let paymentMethod: String
}

private struct MockNotification: Identifiable {
    let id = UUID()
    let title: String
    let message: String
    let time: String
    let icon: String
    let color: Color
    let isRead: Bool
}

private struct MockPin: Identifiable {
    let id = UUID()
    let name: String
    let xOffset: CGFloat
    let yOffset: CGFloat
    let color: Color
}

private enum MockSeed {
    static let professionals: [MockProfessional] = [
        MockProfessional(
            name: "Carlos Méndez",
            title: "Electricista matriculado",
            avatarURL: "https://i.pravatar.cc/300?img=15",
            rating: 4.9,
            reviews: 214,
            price: "Desde $18.000",
            distance: "1.2 km",
            availability: "Hoy 16:00",
            experience: "8 años",
            responseTime: "15 min",
            completedJobs: 426,
            bio: "Especialista en instalaciones eléctricas domiciliarias y comerciales, con enfoque en seguridad, puntualidad y soluciones duraderas.",
            tags: ["Urgencias", "Instalaciones", "Garantía"],
            serviceAreas: ["Palermo", "Villa Crespo", "Almagro"],
            services: [
                MockService(
                    title: "Instalación de tomas y llaves",
                    category: "Electricidad",
                    startingPrice: "Desde $18.000",
                    duration: "60-90 min",
                    rating: 4.9,
                    description: "Instalación y reemplazo de tomas, interruptores y llaves térmicas con verificación de seguridad.",
                    imageURL: "https://images.unsplash.com/photo-1621905251918-48416bd8575a?auto=format&fit=crop&w=1200&q=80",
                    galleryImageURLs: [
                        "https://images.unsplash.com/photo-1581093458791-9f3c3900df4b?auto=format&fit=crop&w=900&q=80",
                        "https://images.unsplash.com/photo-1585776245991-cf89dd7fc73a?auto=format&fit=crop&w=900&q=80",
                        "https://images.unsplash.com/photo-1617040619263-41c5a9ca7521?auto=format&fit=crop&w=900&q=80"
                    ],
                    includes: ["Revisión inicial", "Material menor", "Prueba final de funcionamiento"]
                ),
                MockService(
                    title: "Diagnóstico de tablero eléctrico",
                    category: "Electricidad",
                    startingPrice: "Desde $15.500",
                    duration: "45-60 min",
                    rating: 4.8,
                    description: "Chequeo completo del tablero, detección de fallas y recomendación de mejoras.",
                    imageURL: "https://images.unsplash.com/photo-1620283085068-5ee9b49bcf58?auto=format&fit=crop&w=1200&q=80",
                    galleryImageURLs: [
                        "https://images.unsplash.com/photo-1631545806628-0c6d908c5bdb?auto=format&fit=crop&w=900&q=80",
                        "https://images.unsplash.com/photo-1621905252507-b35492cc74b4?auto=format&fit=crop&w=900&q=80"
                    ],
                    includes: ["Medición de cargas", "Informe básico", "Recomendaciones"]
                )
            ]
        ),
        MockProfessional(
            name: "Sofía Rojas",
            title: "Plomería y gas",
            avatarURL: "https://i.pravatar.cc/300?img=47",
            rating: 4.8,
            reviews: 172,
            price: "Desde $22.000",
            distance: "2.4 km",
            availability: "Mañana",
            experience: "6 años",
            responseTime: "25 min",
            completedJobs: 318,
            bio: "Realiza reparaciones y mantenimiento de plomería y gas, con diagnóstico rápido y presupuesto transparente antes de comenzar.",
            tags: ["24 hs", "Reparaciones", "Presupuesto"],
            serviceAreas: ["Belgrano", "Nuñez", "Colegiales"],
            services: [
                MockService(
                    title: "Reparación de pérdidas de agua",
                    category: "Plomería",
                    startingPrice: "Desde $22.000",
                    duration: "60-120 min",
                    rating: 4.8,
                    description: "Detección y reparación de pérdidas en cocina, baño o cañerías visibles.",
                    imageURL: "https://images.unsplash.com/photo-1585704032915-c3400ca199e7?auto=format&fit=crop&w=1200&q=80",
                    galleryImageURLs: [
                        "https://images.unsplash.com/photo-1590794056226-79ef3a8147e1?auto=format&fit=crop&w=900&q=80",
                        "https://images.unsplash.com/photo-1620653713380-8f7f6f84cae8?auto=format&fit=crop&w=900&q=80"
                    ],
                    includes: ["Diagnóstico", "Repuestos menores", "Prueba de presión"]
                ),
                MockService(
                    title: "Instalación de grifería",
                    category: "Plomería",
                    startingPrice: "Desde $19.500",
                    duration: "45-75 min",
                    rating: 4.7,
                    description: "Colocación de grifería nueva en cocina o baño con sellado y ajuste final.",
                    imageURL: "https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?auto=format&fit=crop&w=1200&q=80",
                    galleryImageURLs: [
                        "https://images.unsplash.com/photo-1572297912072-d6f6f3f5ccf3?auto=format&fit=crop&w=900&q=80",
                        "https://images.unsplash.com/photo-1620626011761-996317b8d101?auto=format&fit=crop&w=900&q=80"
                    ],
                    includes: ["Instalación", "Sellado", "Limpieza final del área"]
                )
            ]
        ),
        MockProfessional(
            name: "Mateo Díaz",
            title: "Limpieza de hogares y oficinas",
            avatarURL: "https://i.pravatar.cc/300?img=59",
            rating: 4.7,
            reviews: 98,
            price: "Desde $14.500",
            distance: "0.9 km",
            availability: "Hoy 18:30",
            experience: "4 años",
            responseTime: "20 min",
            completedJobs: 205,
            bio: "Servicio de limpieza profunda y mantenimiento semanal con productos eco, ideal para hogares, alquileres temporarios y oficinas.",
            tags: ["Eco", "Puntualidad", "Con insumos"],
            serviceAreas: ["Recoleta", "Retiro", "San Nicolás"],
            services: [
                MockService(
                    title: "Limpieza profunda de departamento",
                    category: "Limpieza",
                    startingPrice: "Desde $14.500",
                    duration: "2-3 h",
                    rating: 4.7,
                    description: "Limpieza integral de ambientes, cocina y baño con insumos incluidos.",
                    imageURL: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=1200&q=80",
                    galleryImageURLs: [
                        "https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?auto=format&fit=crop&w=900&q=80",
                        "https://images.unsplash.com/photo-1603712725038-e9334ae8f39f?auto=format&fit=crop&w=900&q=80"
                    ],
                    includes: ["Insumos eco", "Desinfección", "Checklist final"]
                ),
                MockService(
                    title: "Limpieza de oficina",
                    category: "Limpieza",
                    startingPrice: "Desde $18.900",
                    duration: "2 h",
                    rating: 4.6,
                    description: "Servicio orientado a espacios de trabajo con enfoque en áreas comunes y sanitarios.",
                    imageURL: "https://images.unsplash.com/photo-1521791136064-7986c2920216?auto=format&fit=crop&w=1200&q=80",
                    galleryImageURLs: [
                        "https://images.unsplash.com/photo-1517502884422-41eaead166d4?auto=format&fit=crop&w=900&q=80",
                        "https://images.unsplash.com/photo-1484154218962-a197022b5858?auto=format&fit=crop&w=900&q=80"
                    ],
                    includes: ["Aspirado", "Desinfección", "Reposición básica"]
                )
            ]
        ),
        MockProfessional(
            name: "Valentina Cruz",
            title: "Pintura interior y exterior",
            avatarURL: "https://i.pravatar.cc/300?img=32",
            rating: 4.9,
            reviews: 141,
            price: "Desde $26.000",
            distance: "3.1 km",
            availability: "Viernes",
            experience: "10 años",
            responseTime: "35 min",
            completedJobs: 502,
            bio: "Pintora profesional para obras pequeñas y medianas. Incluye asesoría de color, protección de muebles y terminación premium.",
            tags: ["Premium", "Obra limpia", "Asesoría"],
            serviceAreas: ["Caballito", "Flores", "Parque Chacabuco"],
            services: [
                MockService(
                    title: "Pintura interior premium",
                    category: "Pintura",
                    startingPrice: "Desde $26.000",
                    duration: "3-5 h",
                    rating: 4.9,
                    description: "Pintura de interiores con terminación prolija, protección de muebles y asesoría de tonos.",
                    imageURL: "https://images.unsplash.com/photo-1562259949-e8e7689d7828?auto=format&fit=crop&w=1200&q=80",
                    galleryImageURLs: [
                        "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=80",
                        "https://images.unsplash.com/photo-1484154218962-a197022b5858?auto=format&fit=crop&w=900&q=80"
                    ],
                    includes: ["Preparación de superficie", "Pintura doble mano", "Limpieza final"]
                ),
                MockService(
                    title: "Pintura de fachada",
                    category: "Pintura",
                    startingPrice: "Desde $33.000",
                    duration: "1 jornada",
                    rating: 4.8,
                    description: "Renovación de fachada exterior con pinturas resistentes a clima y humedad.",
                    imageURL: "https://images.unsplash.com/photo-1480074568708-e7b720bb3f09?auto=format&fit=crop&w=1200&q=80",
                    galleryImageURLs: [
                        "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=900&q=80",
                        "https://images.unsplash.com/photo-1560185007-c5ca9d2c014d?auto=format&fit=crop&w=900&q=80"
                    ],
                    includes: ["Hidrolavado previo", "Sellador", "Pintura exterior"]
                )
            ]
        )
    ]

    static let featuredServices: [MockService] = professionals.flatMap { $0.services }

    static let reservations: [MockReservation] = [
        MockReservation(
            professional: "Carlos Méndez",
            service: "Revisión de tablero eléctrico",
            date: "Jueves 26 Feb",
            time: "16:00",
            status: "Confirmada",
            color: .green,
            price: "$18.000",
            address: "Honduras 4231, Palermo",
            paymentMethod: "Tarjeta Visa terminada en 2314"
        ),
        MockReservation(
            professional: "Sofía Rojas",
            service: "Reparación de pérdida en cocina",
            date: "Viernes 27 Feb",
            time: "10:30",
            status: "Pendiente",
            color: .orange,
            price: "$22.000",
            address: "Av. Cabildo 1780, Belgrano",
            paymentMethod: "Transferencia"
        ),
        MockReservation(
            professional: "Mateo Díaz",
            service: "Limpieza profunda de departamento",
            date: "Sábado 28 Feb",
            time: "09:00",
            status: "En curso",
            color: .indigo,
            price: "$14.500",
            address: "Billinghurst 1260, Recoleta",
            paymentMethod: "Efectivo"
        )
    ]

    static let activeReservations: [MockReservation] = [
        MockReservation(
            professional: "Valentina Cruz",
            service: "Pintura de living-comedor",
            date: "Hoy",
            time: "14:00",
            status: "Profesional en camino",
            color: .blue,
            price: "$26.000",
            address: "Av. Rivadavia 5120, Caballito",
            paymentMethod: "Tarjeta Master terminada en 7880"
        )
    ]

    static let pastReservations: [MockReservation] = [
        MockReservation(
            professional: "Lucas Pérez",
            service: "Instalación de lámparas",
            date: "Lunes 23 Feb",
            time: "11:00",
            status: "Finalizada",
            color: .green,
            price: "$12.300",
            address: "Paraguay 3300, Palermo",
            paymentMethod: "Tarjeta de débito"
        ),
        MockReservation(
            professional: "Mariana López",
            service: "Mantenimiento de jardín",
            date: "Domingo 22 Feb",
            time: "09:30",
            status: "Cancelada",
            color: .red,
            price: "$9.800",
            address: "Ciudad de la Paz 800, Colegiales",
            paymentMethod: "No cobrado"
        )
    ]

    static let notifications: [MockNotification] = [
        MockNotification(
            title: "Reserva confirmada",
            message: "Carlos aceptó tu solicitud para hoy a las 16:00.",
            time: "Hace 5 min",
            icon: "checkmark.seal.fill",
            color: .green,
            isRead: false
        ),
        MockNotification(
            title: "Nueva promoción",
            message: "10% OFF en servicios de limpieza en tu zona.",
            time: "Hace 1 h",
            icon: "tag.fill",
            color: .orange,
            isRead: false
        ),
        MockNotification(
            title: "Profesional cerca",
            message: "Valentina está disponible a 2 km de tu ubicación.",
            time: "Hace 2 h",
            icon: "location.fill",
            color: .indigo,
            isRead: true
        ),
        MockNotification(
            title: "Recordatorio de reserva",
            message: "Mañana tenés visita de plomería a las 10:30.",
            time: "Ayer",
            icon: "calendar.badge.clock",
            color: .purple,
            isRead: true
        )
    ]

    static let pins: [MockPin] = [
        MockPin(name: "Carlos", xOffset: -112, yOffset: -38, color: .yellow),
        MockPin(name: "Sofía", xOffset: -24, yOffset: -10, color: .blue),
        MockPin(name: "Mateo", xOffset: 74, yOffset: 12, color: .mint),
        MockPin(name: "Valen", xOffset: 120, yOffset: -32, color: .orange),
        MockPin(name: "Leo", xOffset: -62, yOffset: 42, color: .purple),
        MockPin(name: "Ana", xOffset: 12, yOffset: 52, color: .red)
    ]
}

#Preview {
    ContentView()
}
